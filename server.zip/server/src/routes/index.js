import { Router } from 'express';
import customerRoutes from './customerRoutes.js';
import productRoutes from './productRoutes.js';
import supplierRoutes from './supplierRoutes.js';
import materialRoutes from './materialRoutes.js';
import recipeRoutes from './recipeRoutes.js';
import bomRoutes from './bomRoutes.js';
import dashboardRoutes from './dashboardRoutes.js';
import authRoutes from './authRoutes.js';
import locationRoutes from './locationRoutes.js';
import salesOrderRoutes from './salesOrderRoutes.js';
import warehouseRoutes from './warehouseRoutes.js';
import stockOpeningRoutes from './stockOpeningRoutes.js';
import materialReceiptRoutes from './materialReceiptRoutes.js';
import stockTransferRoutes from './stockTransferRoutes.js';
import outboundDeliveryRoutes from './outboundDeliveryRoutes.js';
import materialIssueRoutes from './materialIssueRoutes.js';
import stockMaintenanceRoutes from './stockMaintenanceRoutes.js';
import productionPlanRoutes from './productionPlanRoutes.js';
import {
  productCategoryRoutes,
  leatherTypeRoutes,
  uomRoutes,
  thicknessRoutes,
  standardSizeRoutes,
  colorRoutes,
  finishTypeRoutes,
  gradeRoutes,
  hsnCodeRoutes,
  taxMasterRoutes,
  processStageRoutes,
  groupMasterRoutes,
  machineRoutes,
  rateMasterRoutes,
  roleRoutes,
  companyRoutes,
  businessUnitRoutes,
  locationRackRoutes,
  departmentRoutes,
  costComponentRoutes,
} from './masterRoutes.js';
import settingsRoutes from './settingsRoutes.js';
// New module routes
import batchRoutes from './batchRoutes.js';
import supplierPricingRoutes from './supplierPricingRoutes.js';
import priceApprovalRoutes from './priceApprovalRoutes.js';
import physicalStockEntryRoutes from './physicalStockEntryRoutes.js';
import backupRoutes from './backupRoutes.js';
import exportRoutes from './exportRoutes.js';
import standardCostRoutes from './standardCostRoutes.js';
import generalCostRoutes from './generalCostRoutes.js';
import machineCostRoutes from './machineCostRoutes.js';
import productionStatusRoutes from './productionStatusRoutes.js';
import costingReportRoutes from './costingReportRoutes.js';
import reportsRoutes from './reportsRoutes.js';
import materialRequirementRoutes from './materialRequirementRoutes.js';
import materialTransferNoteRoutes from './materialTransferNoteRoutes.js';

const router = Router();

// Auth routes
router.use('/auth', authRoutes);

// Users routes
router.use(settingsRoutes.usersRouter);

// Master data routes
router.use('/customers', customerRoutes);
router.use('/products', productRoutes);
router.use('/suppliers', supplierRoutes);
router.use('/materials', materialRoutes);
router.use('/sales-orders', salesOrderRoutes);
router.use('/recipes', recipeRoutes);
router.use('/boms', bomRoutes);

// Inventory routes
router.use('/warehouses', warehouseRoutes);
router.use('/stock-opening', stockOpeningRoutes);
router.use('/material-receipts', materialReceiptRoutes);
router.use('/stock-transfers', stockTransferRoutes);
router.use('/outbound-deliveries', outboundDeliveryRoutes);
router.use('/material-issues', materialIssueRoutes);
router.use('/stock-maintenance', stockMaintenanceRoutes);

// Production routes
router.use('/production-plans', productionPlanRoutes);

// Location routes (countries, states, cities)
router.use('/locations', locationRoutes);

// Master tables routes
router.use('/product-categories', productCategoryRoutes);
router.use('/leather-types', leatherTypeRoutes);
router.use('/uom', uomRoutes);
router.use('/thickness', thicknessRoutes);
router.use('/standard-sizes', standardSizeRoutes);
router.use('/colors', colorRoutes);
router.use('/finish-types', finishTypeRoutes);
router.use('/grades', gradeRoutes);
router.use('/hsn-codes', hsnCodeRoutes);
router.use('/tax-master', taxMasterRoutes);
router.use('/process-stages', processStageRoutes);
router.use('/group-master', groupMasterRoutes);
router.use('/machines', machineRoutes);
router.use('/rate-master', rateMasterRoutes);
router.use('/location-racks', locationRackRoutes);

// Department Master routes
router.use('/departments', departmentRoutes);

// Cost Component Master routes
router.use('/cost-components', costComponentRoutes);

// Settings routes
router.use('/roles', roleRoutes);
router.use('/companies', companyRoutes);
router.use('/business-units', businessUnitRoutes);

// New Module Routes
// Batch / Lot Tracking routes
router.use('/batches', batchRoutes);

// Supplier Pricing routes
router.use('/supplier-pricing', supplierPricingRoutes);

// Price Approval routes
router.use('/price-approvals', priceApprovalRoutes);

// Physical Stock Entry routes
router.use('/physical-stock-entries', physicalStockEntryRoutes);

// Database Backup routes
router.use('/backups', backupRoutes);

// Excel Export routes
router.use('/export', exportRoutes);

// Standard Costing routes
router.use('/standard-costs', standardCostRoutes);

// General Cost routes
router.use('/general-costs', generalCostRoutes);

// Machine Cost routes
router.use('/machine-costs', machineCostRoutes);

// Production Status routes
router.use('/production-status', productionStatusRoutes);

// Costing Report routes
router.use('/costing-report', costingReportRoutes);

// New consolidated Reports module (Inventory / Production / Sales / Costing)
router.use('/reports', reportsRoutes);

// Material Requirement (Sale Order → BOM requirement calculation)
router.use('/material-requirement', materialRequirementRoutes);

// Material Transfer Note (Production Plan → BOM norms × planned qty)
router.use('/material-transfer-notes', materialTransferNoteRoutes);

// Dashboard routes
router.use('/dashboard', dashboardRoutes);

export default router;
