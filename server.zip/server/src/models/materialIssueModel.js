import pool from '../config/db.js';
import { updateStock, addLedgerEntry, allowsNegativeStock, rebuildAndReprice } from './stockLedgerModel.js';
import { getIssueItemInfo, replaceReferenceTransactions, ensureOpeningStockSeeded } from './materialTransactionModel.js';
import { isPlanCostLockedByPlanNo } from './standardCostModel.js';

// Reject the save when any line's issue quantity exceeds available stock, so an
// out-of-stock material issue is never persisted — not even as a Draft. Skipped
// for warehouses explicitly configured to allow negative stock.
async function assertStockAvailable(conn, data, items = []) {
  if (!data.warehouse_id || !items.length) return;
  if (await allowsNegativeStock(data.warehouse_id)) return;
  for (const item of items) {
    const requested = parseFloat(item.issue_qty) || 0;
    if (requested <= 0) continue;
    const info = await getIssueItemInfo({ warehouseId: data.warehouse_id, itemId: item.material_id, date: data.issue_date });
    if (requested > info.available_qty + 0.000001) {
      throw new Error(`Insufficient stock. Available stock: ${info.available_qty}. Requested issue quantity: ${requested}`);
    }
  }
}

export async function getAll({ search, status, warehouse_id, process_stage, page = 1, limit = 10, sortBy, sortOrder }) {
  let where = 'mi.deleted_at IS NULL';
  const params = [];
  if (search) {
    where += ' AND (mi.issue_no LIKE ? OR mi.production_batch LIKE ? OR mi.job_order_no LIKE ? OR w.name LIKE ?)';
    const t = `%${search}%`;
    params.push(t, t, t, t);
  }
  if (status) { where += ' AND mi.status = ?'; params.push(status); }
  if (warehouse_id) { where += ' AND mi.warehouse_id = ?'; params.push(warehouse_id); }
  if (process_stage) { where += ' AND mi.process_stage = ?'; params.push(process_stage); }

  const allowed = ['id', 'issue_no', 'issue_date', 'grand_total', 'status', 'created_at'];
  const col = allowed.includes(sortBy) ? `mi.\`${sortBy}\`` : 'mi.`id`';
  const ord = sortOrder === 'asc' ? 'ASC' : 'DESC';
  const offset = (page - 1) * limit;

  const [rows] = await pool.query(
    `SELECT mi.*,
       w.name AS warehouse_name, w.code AS warehouse_code
     FROM material_issues mi
     LEFT JOIN warehouses w ON mi.warehouse_id = w.id
     WHERE ${where} ORDER BY ${col} ${ord} LIMIT ? OFFSET ?`,
    [...params, Number(limit), Number(offset)]
  );
  const [[{ total }]] = await pool.query(
    `SELECT COUNT(*) AS total FROM material_issues mi
     LEFT JOIN warehouses w ON mi.warehouse_id = w.id
     WHERE ${where}`, params
  );
  return { rows, total };
}

export async function getById(id) {
  const [[issue]] = await pool.query(
    `SELECT mi.*, w.name AS warehouse_name, w.code AS warehouse_code
     FROM material_issues mi
     LEFT JOIN warehouses w ON mi.warehouse_id = w.id
     WHERE mi.id = ? AND mi.deleted_at IS NULL`, [id]
  );
  if (!issue) return null;
  const [items] = await pool.query(
    `SELECT mii.*, m.name AS material_name, m.code AS material_code, g.name AS group_name
     FROM material_issue_items mii
     LEFT JOIN materials m ON mii.material_id = m.id
     LEFT JOIN group_master g ON m.group_id = g.id
     WHERE mii.issue_id = ? ORDER BY mii.id ASC`, [id]
  );
  return { ...issue, items };
}

export async function getNextNo() {
  const year = new Date().getFullYear();
  const [[row]] = await pool.query(
    `SELECT issue_no FROM material_issues WHERE issue_no LIKE ? ORDER BY id DESC LIMIT 1`,
    [`ISS-${year}-%`]
  );
  // Note: deleted (soft) issues are intentionally still considered here so a
  // reused number is never generated after a soft delete.
  if (!row) return `ISS-${year}-00001`;
  const num = parseInt(row.issue_no.split('-')[2], 10) + 1;
  return `ISS-${year}-${String(num).padStart(5, '0')}`;
}

export async function create(data, items = [], createdBy = null) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const issue_no = data.issue_no || await getNextNo();
    const status = data.status || 'Draft';

    if (status === 'Posted') {
      for (const item of items) {
        // Materialize master opening stock into a real transaction/ledger row
        // when this warehouse has no stock record yet (and it's the material's
        // default warehouse). Keeps the ledger consistent after issuing.
        await ensureOpeningStockSeeded(conn, { warehouseId: data.warehouse_id, itemId: item.material_id, date: data.issue_date });
        const info = await getIssueItemInfo({ warehouseId: data.warehouse_id, itemId: item.material_id, date: data.issue_date });
        const requested = parseFloat(item.issue_qty) || 0;
        if (requested > info.available_qty + 0.000001) {
          throw new Error(`Insufficient stock. Available stock: ${info.available_qty}. Current balance: ${info.available_qty}. Requested issue quantity: ${requested}`);
        }
        item.unit_cost = info.avg_rate;
        item.amount = Number((requested * info.avg_rate).toFixed(2));
      }
    } else {
      // Even for Draft saves, never persist an issue whose quantity exceeds
      // available stock. This keeps out-of-stock entries out of the DB entirely
      // (the record must not be created at all when insufficient).
      await assertStockAvailable(conn, data, items);
    }

    const totalCost = items.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
    const grandTotal = totalCost + (parseFloat(data.loading_unloading) || 0) + (parseFloat(data.other_charges) || 0);

    const [result] = await conn.query(
      `INSERT INTO material_issues (
        issue_no, issue_date, department, job_order_no, production_batch, process_stage, article, color, batch_qty,
        batch_uom, batch_description, costing_method, warehouse_id, required_date, planned_date,
        issued_by, loading_unloading, other_charges, total_material_cost, grand_total,
        remarks, status, created_by
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        issue_no, data.issue_date, data.department || null, data.job_order_no || null,
        data.production_batch || null, data.process_stage || null, data.article || data.batch_description || null, data.color || null, data.batch_qty || 0, data.batch_uom || null,
        data.batch_description || null, data.costing_method || 'FIFO', data.warehouse_id,
        data.required_date || data.planned_date || null, data.planned_date || data.required_date || null, data.issued_by || null, data.loading_unloading || 0,
        data.other_charges || 0, totalCost, grandTotal, data.remarks || null,
        status, createdBy,
      ]
    );
    const issueId = result.insertId;

    for (const item of items) {
      await conn.query(
        `INSERT INTO material_issue_items (issue_id, material_id, uom, required_qty, issue_qty, unit_cost, amount, remarks)
         VALUES (?,?,?,?,?,?,?,?)`,
        [issueId, item.material_id, item.uom || null, item.required_qty || 0,
         item.issue_qty || 0, item.unit_cost || 0, item.amount || 0, item.remarks || null]
      );
    }

    // Only affect stock/transactions if posting
    if (status === 'Posted') {
      for (const item of items) {
        await updateStock(conn, data.warehouse_id, item.material_id, item.uom, -(parseFloat(item.issue_qty) || 0), 0);
        await addLedgerEntry(conn, {
          transaction_date: data.issue_date,
          transaction_type: 'Issue',
          reference_type: 'material_issue',
          reference_id: issueId,
          reference_no: issue_no,
          warehouse_id: data.warehouse_id,
          material_id: item.material_id,
          uom: item.uom,
          in_qty: 0,
          out_qty: item.issue_qty || 0,
          unit_cost: item.unit_cost || 0,
          amount: item.amount || 0,
          balance_qty: -(item.issue_qty || 0),
          remarks: `Issue to batch ${data.production_batch || ''}`,
          created_by: createdBy,
        });
      }

      await replaceReferenceTransactions(conn, 'material_issue', issueId, items.map((item) => ({
        transaction_date: data.issue_date,
        transaction_type: 'Issue',
        reference_no: issue_no,
        warehouse_id: data.warehouse_id,
        item_id: item.material_id,
        receipt_qty: 0,
        opening_stock: null,
        opening_value: null,
        receipt_value: 0,
        issue_qty: parseFloat(item.issue_qty) || 0,
        issue_value: parseFloat(item.amount) || 0,
      })));

      // Date-ordered rebuild of the live stock ledger (System A) so a backdated
      // issue correctly shifts later balances/rates in the inventory reports.
      for (const item of items) {
        await rebuildAndReprice(conn, data.warehouse_id, item.material_id);
      }
    }

    await conn.commit();
    return { id: issueId, issue_no };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function update(id, data, items = [], updatedBy = null) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Check current status
    const [[current]] = await conn.query('SELECT status, issue_no, production_batch FROM material_issues WHERE id=?', [id]);
    const wasPosted = current && current.status === 'Posted';
    const newStatus = data.status || current?.status || 'Draft';

    // Lock when the order's standard cost is Approved/Posted — same rule as
    // machine & general cost. The material issue references the plan via
    // production_batch (= production_plans.plan_no). Check both the stored and
    // the incoming batch so a re-point to a locked order is also blocked.
    const batchNo = data.production_batch || current?.production_batch || null;
    if (await isPlanCostLockedByPlanNo(conn, batchNo)) {
      const err = new Error('Cannot edit: the standard cost for this order is Approved and locked');
      err.status = 403;
      throw err;
    }

    // Track every (warehouse, material) pair affected by old or new version.
    const affectedPairs = new Map();

    // If it was posted, reverse old stock first
    if (wasPosted) {
      const [prevLedger] = await conn.query(
        'SELECT DISTINCT warehouse_id, material_id FROM stock_ledger WHERE reference_type=? AND reference_id=?',
        ['material_issue', id]
      );
      for (const p of prevLedger) affectedPairs.set(`${p.warehouse_id}:${p.material_id}`, { w: p.warehouse_id, m: p.material_id });

      const [oldItems] = await conn.query(
        'SELECT material_id, uom, issue_qty FROM material_issue_items WHERE issue_id=?', [id]
      );
      for (const old of oldItems) {
        await updateStock(conn, data.warehouse_id, old.material_id, old.uom, parseFloat(old.issue_qty), 0);
      }
      await conn.query('DELETE FROM stock_ledger WHERE reference_type=? AND reference_id=?', ['material_issue', id]);
      await replaceReferenceTransactions(conn, 'material_issue', id, []);
    }

    // If posting, validate stock and compute costs
    if (newStatus === 'Posted') {
      for (const item of items) {
        await ensureOpeningStockSeeded(conn, { warehouseId: data.warehouse_id, itemId: item.material_id, date: data.issue_date });
        const info = await getIssueItemInfo({ warehouseId: data.warehouse_id, itemId: item.material_id, date: data.issue_date });
        const requested = parseFloat(item.issue_qty) || 0;
        if (requested > info.available_qty + 0.000001) {
          throw new Error(`Insufficient stock. Available stock: ${info.available_qty}. Current balance: ${info.available_qty}. Requested issue quantity: ${requested}`);
        }
        item.unit_cost = info.avg_rate;
        item.amount = Number((requested * info.avg_rate).toFixed(2));
      }
    } else if (!wasPosted) {
      // Pure Draft update (record was never Posted): reject if any line exceeds
      // available stock so an out-of-stock issue is never persisted. We skip
      // this when the record WAS Posted, because the in-transaction stock
      // reversal above isn't yet visible to the availability read and would
      // cause a false "insufficient" during un-posting back to Draft.
      await assertStockAvailable(conn, data, items);
    }

    const totalCost = items.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
    const grandTotal = totalCost + (parseFloat(data.loading_unloading) || 0) + (parseFloat(data.other_charges) || 0);

    await conn.query(
      `UPDATE material_issues SET
        issue_date=?, department=?, job_order_no=?, production_batch=?, process_stage=?, article=?, color=?, batch_qty=?,
        batch_uom=?, batch_description=?, costing_method=?, warehouse_id=?, required_date=?, planned_date=?,
        issued_by=?, loading_unloading=?, other_charges=?, total_material_cost=?,
        grand_total=?, remarks=?, status=?, updated_by=? WHERE id=?`,
      [
        data.issue_date, data.department || null, data.job_order_no || null,
        data.production_batch || null, data.process_stage || null, data.article || data.batch_description || null, data.color || null, data.batch_qty || 0, data.batch_uom || null,
        data.batch_description || null, data.costing_method || 'FIFO', data.warehouse_id,
        data.required_date || data.planned_date || null, data.planned_date || data.required_date || null, data.issued_by || null, data.loading_unloading || 0,
        data.other_charges || 0, totalCost, grandTotal, data.remarks || null, newStatus, updatedBy, id,
      ]
    );

    // Re-insert items
    await conn.query('DELETE FROM material_issue_items WHERE issue_id=?', [id]);
    for (const item of items) {
      await conn.query(
        `INSERT INTO material_issue_items (issue_id, material_id, uom, required_qty, issue_qty, unit_cost, amount, remarks)
         VALUES (?,?,?,?,?,?,?,?)`,
        [id, item.material_id, item.uom || null, item.required_qty || 0,
         item.issue_qty || 0, item.unit_cost || 0, item.amount || 0, item.remarks || null]
      );
    }

    // Only affect stock/transactions if posting
    if (newStatus === 'Posted') {
      for (const item of items) {
        await updateStock(conn, data.warehouse_id, item.material_id, item.uom, -(parseFloat(item.issue_qty) || 0), 0);
      }

      const issue_no = data.issue_no || current?.issue_no || null;
      await replaceReferenceTransactions(conn, 'material_issue', id, items.map((item) => ({
        transaction_date: data.issue_date,
        transaction_type: 'Issue',
        reference_no: issue_no,
        warehouse_id: data.warehouse_id,
        item_id: item.material_id,
        receipt_qty: 0,
        opening_stock: null,
        opening_value: null,
        receipt_value: 0,
        issue_qty: parseFloat(item.issue_qty) || 0,
        issue_value: parseFloat(item.amount) || 0,
      })));

      for (const it of items) affectedPairs.set(`${data.warehouse_id}:${it.material_id}`, { w: data.warehouse_id, m: it.material_id });
    }

    // Date-ordered rebuild of System A for every affected pair (old + new).
    for (const p of affectedPairs.values()) {
      await rebuildAndReprice(conn, p.w, p.m);
    }

    await conn.commit();
    return true;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function remove(id) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // A Draft issue never affected stock (create/update only touch stock when
    // status === 'Posted'). So a Draft delete must NOT reverse stock, ledger or
    // transactions — otherwise it would add phantom stock. Only a Posted issue
    // needs its stock effects reversed.
    const [[current]] = await conn.query('SELECT status, production_batch FROM material_issues WHERE id=?', [id]);
    const wasPosted = current && current.status === 'Posted';

    // Lock delete when the order's standard cost is Approved/Posted — same rule
    // as machine & general cost.
    if (await isPlanCostLockedByPlanNo(conn, current?.production_batch)) {
      const err = new Error('Cannot delete: the standard cost for this order is Approved and locked');
      err.status = 403;
      throw err;
    }

    const [items] = await conn.query(
      'SELECT material_id, uom, issue_qty, warehouse_id FROM material_issue_items mii JOIN material_issues mi ON mii.issue_id = mi.id WHERE mii.issue_id=?',
      [id]
    );

    if (wasPosted) {
      // Reverse the stock the posted issue consumed, then remove its ledger and
      // transaction effects and rebuild valuation. The stock side-effects must
      // be undone so inventory stays accurate even though the header is only
      // soft-deleted.
      for (const item of items) {
        await updateStock(conn, item.warehouse_id, item.material_id, item.uom, parseFloat(item.issue_qty), 0);
      }
      await conn.query('DELETE FROM stock_ledger WHERE reference_type=? AND reference_id=?', ['material_issue', id]);
      await replaceReferenceTransactions(conn, 'material_issue', id, []);
    }

    // Soft delete: flag the header with deleted_at instead of physically
    // removing it. Child items are kept intact so the record can be restored
    // and remains available for audit/history.
    const [result] = await conn.query(
      'UPDATE material_issues SET deleted_at = CURRENT_TIMESTAMP WHERE id=? AND deleted_at IS NULL', [id]
    );

    // Rebuild valuation only for Posted issues (Draft never touched stock).
    if (wasPosted) {
      for (const item of items) {
        await rebuildAndReprice(conn, item.warehouse_id, item.material_id);
      }
    }

    await conn.commit();
    return result.affectedRows > 0;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function getStats() {
  const [[data]] = await pool.query(
    `SELECT COUNT(*) AS total,
       SUM(status='Posted') AS posted,
       SUM(status='Draft') AS draft,
       SUM(grand_total) AS total_value
     FROM material_issues
     WHERE deleted_at IS NULL`
  );
  return data;
}

// Bulk set status (Draft/Posted) for several issues at once. Each record is
// processed through the normal update() path so stock validation, ledger
// writes and valuation rebuilds behave exactly like a single-record post.
// Returns { success, failed: [{ id, error }] }.
export async function bulkSetStatus(ids, status, updatedBy = null) {
  const failed = [];
  let success = 0;
  for (const id of ids) {
    try {
      const existing = await getById(id);
      if (!existing) { failed.push({ id, error: 'Not found' }); continue; }
      if (existing.status === status) { success++; continue; } // already in target state
      const { items = [], ...header } = existing;
      await update(id, { ...header, status }, items, updatedBy);
      success++;
    } catch (err) {
      failed.push({ id, error: err.message });
    }
  }
  return { success, failed };
}

export async function bulkDelete(ids) {
  const failed = [];
  let success = 0;
  for (const id of ids) {
    try {
      const ok = await remove(id);
      if (ok) success++; else failed.push({ id, error: 'Not found' });
    } catch (err) {
      failed.push({ id, error: err.message });
    }
  }
  return { success, failed };
}

// --- Batches Dropdown for Material Issue ---
export async function getBatchesDropdown() {
  const [rows] = await pool.query(
    `SELECT b.id, b.batch_no, b.article_name, b.total_receipt_qty,
       pp.product_id, pp.batch_qty, pp.uom AS batch_uom,
       p.name AS product_name, p.code AS product_code
     FROM batches b
     LEFT JOIN production_plans pp ON b.production_plan_id = pp.id
     LEFT JOIN products p ON pp.product_id = p.id
     WHERE b.deleted_at IS NULL AND b.status IN ('In Progress', 'Pending', 'Draft')
     ORDER BY b.id DESC`
  );
  return rows;
}

// --- BOM Items for Material Issue (by product) ---
export async function getBOMItemsByProduct(productId) {
  const [rows] = await pool.query(
    `SELECT bi.material_id, bi.qty, bi.uom, bi.unit_cost,
       m.code AS material_code, m.name AS material_name, g.name AS group_name
     FROM boms b
     JOIN bom_items bi ON b.id = bi.bom_id
     JOIN materials m ON bi.material_id = m.id
     LEFT JOIN group_master g ON m.group_id = g.id
     WHERE b.product_id = ? AND b.status = 'Active'
     ORDER BY bi.id`,
    [productId]
  );
  return rows;
}

// --- Production plan + its stages by plan_no (for Material Issue autopopulation) ---
export async function getPlanWithStagesByNo(planNo) {
  if (!planNo) return null;
  const [[plan]] = await pool.query(
    `SELECT id, plan_no, article, color, product_id, planned_qty, uom,
       plan_date, planned_start_date, planned_end_date, warehouse_id
     FROM production_plans
     WHERE plan_no = ? AND deleted_at IS NULL
     ORDER BY id DESC LIMIT 1`,
    [planNo]
  );
  if (!plan) return null;
  const [stages] = await pool.query(
    `SELECT pps.id, pps.seq, pps.stage_id, pps.stage_name, pps.planned_qty,
       ps.uom AS stage_uom, ps.name AS process_stage_name
     FROM production_plan_stages pps
     LEFT JOIN process_stages ps ON pps.stage_id = ps.id
     WHERE pps.plan_id = ?
     ORDER BY pps.seq ASC, pps.id ASC`,
    [plan.id]
  );
  return { ...plan, stages };
}

export async function getPreviousIssueByArticle(article, excludeId = null) {
  if (!article) return null;
  const params = [article];
  let extra = '';
  if (excludeId) { extra = ' AND mi.id <> ?'; params.push(excludeId); }
  const [[header]] = await pool.query(
    `SELECT mi.* FROM material_issues mi WHERE mi.article=? AND mi.deleted_at IS NULL${extra} ORDER BY mi.issue_date DESC, mi.id DESC LIMIT 1`, params
  );
  if (!header) return null;
  const [items] = await pool.query(
    `SELECT mii.*, m.name AS material_name, m.code AS material_code, g.name AS group_name
     FROM material_issue_items mii JOIN materials m ON mii.material_id=m.id
     LEFT JOIN group_master g ON m.group_id = g.id
     WHERE mii.issue_id=? ORDER BY mii.id`, [header.id]
  );
  return { ...header, items };
}
