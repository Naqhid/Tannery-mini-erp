import * as model from '../models/generalCostModel.js';

export async function listOrders(req, res, next) {
  try {
    const { search, status, process_stage, show_completed, has_entry, view, sortBy, sortOrder } = req.query;
    const { page, limit } = req;
    // Transaction tab shows one row per cost line (transaction no, production
    // date, cost category, uom, amount, cost/piece).
    if (view === 'transaction') {
      const { rows, total } = await model.getTransactionLines({ search, process_stage, page, limit, sortBy, sortOrder });
      const totalPages = Math.ceil(total / limit);
      return res.json({ data: rows, total, page, limit, totalPages });
    }
    const { rows, total } = await model.getOrders({ search, status, process_stage, show_completed, has_entry, page, limit, sortBy, sortOrder });
    const totalPages = Math.ceil(total / limit);
    res.json({ data: rows, total, page, limit, totalPages });
  } catch (err) { next(err); }
}

export async function getOrdersByPlan(req, res, next) {
  try {
    const rows = await model.getOrdersByPlan(req.params.planId);
    res.json({ data: rows });
  } catch (err) { next(err); }
}

export async function getStagesForOrder(req, res, next) {
  try {
    const rows = await model.getStagesForOrder(req.params.orderId);
    res.json({ data: rows });
  } catch (err) { next(err); }
}

export async function getOne(req, res, next) {
  try {
    const entry = await model.getById(req.params.id);
    if (!entry) return res.status(404).json({ error: 'General Cost entry not found' });
    res.json({ data: entry });
  } catch (err) { next(err); }
}

export async function getByPlan(req, res, next) {
  try {
    const entry = await model.getByPlanId(req.params.planId);
    if (!entry) return res.status(404).json({ error: 'No general cost entry for this plan' });
    res.json({ data: entry });
  } catch (err) { next(err); }
}

export async function getNextNo(req, res, next) {
  try {
    const transaction_no = await model.getNextTransactionNo();
    res.json({ data: { transaction_no } });
  } catch (err) { next(err); }
}

export async function previousCost(req, res, next) {
  try {
    const { article, process_stage, exclude_id } = req.query;
    if (!article) return res.status(400).json({ error: 'article is required' });
    const data = await model.getPreviousCostItems({ article, process_stage, exclude_id: exclude_id || null });
    if (!data) return res.status(404).json({ error: 'No previous general cost found for this article' });
    res.json({ data });
  } catch (err) { next(err); }
}

export async function create(req, res, next) {
  try {
    if (!req.body.production_plan_id) return res.status(400).json({ error: 'production_plan_id is required' });
    const userId = req.user?.id || null;
    const result = await model.create(req.body, userId);
    res.status(201).json({ data: result, message: 'General Cost entry created successfully!' });
  } catch (err) { next(err); }
}

export async function update(req, res, next) {
  try {
    const userId = req.user?.id || null;
    const result = await model.update(req.params.id, req.body, userId);
    res.json({ data: result, message: 'General Cost entry updated successfully!' });
  } catch (err) {
    if (err.message?.includes('Cannot edit')) {
      return res.status(403).json({ error: err.message });
    }
    next(err);
  }
}

export async function post(req, res, next) {
  try {
    const userId = req.user?.id || null;
    const ok = await model.post(req.params.id, userId);
    if (!ok) return res.status(404).json({ error: 'General Cost entry not found' });
    res.json({ data: { id: req.params.id, status: 'Posted' }, message: 'General Cost posted successfully!' });
  } catch (err) {
    if (err.message?.includes('Already posted')) {
      return res.status(400).json({ error: err.message });
    }
    next(err);
  }
}

export async function remove(req, res, next) {
  try {
    const ok = await model.remove(req.params.id);
    if (!ok) return res.status(404).json({ error: 'General Cost entry not found' });
    res.json({ data: { id: req.params.id, deleted: true }, message: 'General Cost entry deleted successfully!' });
  } catch (err) {
    if (err.message?.includes('Cannot delete')) {
      return res.status(403).json({ error: err.message });
    }
    next(err);
  }
}
