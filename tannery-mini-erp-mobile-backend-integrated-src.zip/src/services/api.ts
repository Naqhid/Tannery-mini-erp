const API_BASE = (import.meta.env.VITE_API_BASE_URL || '/api').replace(/\/$/, '');

export type ApiList<T> = { data: T[]; total?: number; page?: number; limit?: number };
export async function apiGet<T>(path: string): Promise<T> {
  const token = localStorage.getItem('token') || localStorage.getItem('accessToken');
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { Accept: 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  if (!response.ok) {
    const message = await response.text().catch(() => '');
    throw new Error(message || `Request failed (${response.status})`);
  }
  return response.json() as Promise<T>;
}
export const unwrap = <T,>(payload: any): T => payload?.data ?? payload;
