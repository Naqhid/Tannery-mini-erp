Tannery ERP mobile frontend — backend integrated

Contents:
- App.tsx: mobile screens; loads live data from the existing backend.
- services/api.ts: shared fetch helper.
- main.tsx and index.css: entry point and retained mockup styling.

API base:
- Default: /api (recommended when frontend and backend are served behind the same Nginx origin).
- If your API is hosted separately, add VITE_API_BASE_URL to the frontend project's .env, for example:
  VITE_API_BASE_URL=https://your-api-host.example/api
  Do not put secrets in this variable.

Endpoints used from the supplied backend:
- GET /api/dashboard/stats
- GET /api/sales-orders?page=1&limit=50&sortBy=order_date&sortOrder=desc
- GET /api/materials?page=1&limit=100&sortBy=name&sortOrder=asc
- GET /api/production-status/orders?page=1&limit=50
- GET /api/costing-report?page=1&limit=50

No sample business figures or mock records are embedded in the new App.tsx. Empty/loading/error states are displayed when APIs return no records or fail. The existing backend currently supplies a summary dashboard endpoint and separate lists/reports; the UI uses those available endpoints.

Authentication:
- The API helper forwards a Bearer token if `token` or `accessToken` exists in localStorage. This does not implement a new login screen or change the existing auth flow.

Replace your project's src folder with this src folder. Keep your existing package.json, Vite config and Tailwind setup. Restart the dev server after setting VITE_API_BASE_URL.
