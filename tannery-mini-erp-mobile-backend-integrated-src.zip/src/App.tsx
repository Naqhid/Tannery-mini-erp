import React, { useCallback, useEffect, useMemo, useState } from 'react';
import './index.css';
import { apiGet } from './services/api';

type AnyRow = Record<string, any>;
type Dashboard = {
  stats?: AnyRow[]; recentOrders?: AnyRow[]; lowStock?: AnyRow[];
  productionOrders?: { counts?: AnyRow; orders?: AnyRow };
  highestWipStages?: AnyRow[]; kpiCounts?: AnyRow; salesTrend?: AnyRow[];
  inventoryValue?: { total?: number; breakdown?: AnyRow[] }; topProducts?: AnyRow[];
  recentReceipts?: AnyRow[]; quickSummary?: AnyRow; counts?: AnyRow;
};
const n = (v: any) => Number(v ?? 0) || 0;
const fmt = (v: any) => n(v).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const money = (v: any) => `₹${fmt(v)}`;
const val = (row: AnyRow, ...keys: string[]) => {
  for (const key of keys) if (row?.[key] !== undefined && row?.[key] !== null && row[key] !== '') return row[key];
  return '—';
};
const date = (v: any) => v ? new Date(v).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const statusClass = (s: any) => String(s || '').toLowerCase().replace(/\s+/g, '-');
const errText = (e: unknown) => e instanceof Error ? e.message : 'Unable to load data';

export default function App() {
  const [activeScreen, setActiveScreen] = useState('home');
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [orders, setOrders] = useState<AnyRow[]>([]);
  const [materials, setMaterials] = useState<AnyRow[]>([]);
  const [production, setProduction] = useState<AnyRow[]>([]);
  const [costing, setCosting] = useState<AnyRow[]>([]);
  const [activeSheet, setActiveSheet] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [articleFilter, setArticleFilter] = useState('all');
  const [search, setSearch] = useState('');

  const loadData = useCallback(async (refresh = false) => {
    refresh ? setRefreshing(true) : setLoading(true);
    const failures: string[] = [];
    const jobs = [
      apiGet<any>('/dashboard/stats').then(r => setDashboard(r?.data ?? r)),
      apiGet<any>('/sales-orders?page=1&limit=50&sortBy=order_date&sortOrder=desc').then(r => setOrders(Array.isArray(r?.data) ? r.data : [])),
      apiGet<any>('/materials?page=1&limit=100&sortBy=name&sortOrder=asc').then(r => setMaterials(Array.isArray(r?.data) ? r.data : [])),
      apiGet<any>('/production-status/orders?page=1&limit=50').then(r => setProduction(Array.isArray(r?.data) ? r.data : [])),
      apiGet<any>('/costing-report?page=1&limit=50').then(r => setCosting(Array.isArray(r?.data) ? r.data : [])),
    ];
    const labels = ['Dashboard', 'Sales orders', 'Inventory', 'Production', 'Costing'];
    const results = await Promise.allSettled(jobs);
    results.forEach((r, i) => { if (r.status === 'rejected') failures.push(`${labels[i]}: ${errText(r.reason)}`); });
    setErrors(failures);
    setLoading(false); setRefreshing(false);
  }, []);

  useEffect(() => { void loadData(); }, [loadData]);
  const showScreen = (id: string) => { setActiveScreen(id); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const filteredOrders = useMemo(() => orders.filter(o => !search || JSON.stringify(o).toLowerCase().includes(search.toLowerCase())), [orders, search]);
  const filteredMaterials = useMemo(() => materials.filter(m => !search || JSON.stringify(m).toLowerCase().includes(search.toLowerCase())), [materials, search]);
  const filteredProduction = useMemo(() => production.filter(p => !search || JSON.stringify(p).toLowerCase().includes(search.toLowerCase())), [production, search]);
  const filteredCosting = useMemo(() => costing.filter(c => articleFilter === 'all' || val(c, 'article') === articleFilter), [costing, articleFilter]);
  const kpis = dashboard?.kpiCounts || {};
  const inventory = dashboard?.inventoryValue || {};
  const wipStages = dashboard?.highestWipStages || [];
  const lowStock = dashboard?.lowStock || [];
  const orderStats = dashboard?.quickSummary || {};
  const orderTotal = n(val(kpis, 'totalSalesOrders', 'total_sales_orders', 'salesOrders', 'total_orders')) || orders.length;
  const openOrders = orders.filter(o => !['completed', 'delivered', 'cancelled', 'canceled'].includes(String(o.status || '').toLowerCase()));
  const orderedQty = orders.reduce((sum, o) => sum + n(val(o, 'total_quantity', 'totalQuantity', 'quantity')), 0);
  const stockCount = materials.length;
  const currentSheetTitle = activeSheet === 'orders' ? 'Sales orders' : activeSheet === 'inventory' ? 'Inventory valuation' : activeSheet === 'wip' ? 'Work in progress' : activeSheet === 'stock' ? 'Stock exceptions' : 'ERP details';
  const currentSheetBody = activeSheet === 'orders' ? `${orders.length} orders currently returned by the API.` :
    activeSheet === 'inventory' ? `Live inventory valuation returned by the dashboard API: ${money(inventory.total)}.` :
    activeSheet === 'wip' ? `${wipStages.length} work-in-progress stages returned by the dashboard API.` :
    activeSheet === 'stock' ? `${lowStock.length} materials are at or below their reorder level.` : 'Details are loaded from your existing ERP backend.';
  const nav = [{id:'home', label:'Home', icon:'⌂'}, {id:'orders',label:'Orders',icon:'▤'}, {id:'inventory',label:'Inventory',icon:'▦'}, {id:'costing',label:'Costing',icon:'₹'}, {id:'production',label:'Production',icon:'⚙'}];

  return <div className="shell">
    <header className="top">
      <div className="toprow"><div className="brand"><div className="logo">◈</div><div><h1>TANNERY ERP</h1><small>Operations at a glance</small></div></div><button className="avatar" onClick={() => void loadData(true)} aria-label="Refresh data">{refreshing ? '…' : '↻'}</button></div>
      <div className="greeting"><div className="eyebrow">MANAGEMENT DASHBOARD</div><h2>Leather operations overview</h2><p>Live data from your Tannery ERP backend</p></div>
      <div className="datebar"><span className="pill">📅 {date(new Date())}</span><span className="pill">⌁ All units</span><span className="pill">{refreshing ? '↻ Refreshing…' : '● API connected'}</span></div>
    </header>
    <main>
      {errors.length > 0 && <div className="panel apiwarning"><b>Some data could not be loaded</b><ul>{errors.map(e => <li key={e}>{e}</li>)}</ul><button onClick={() => void loadData(true)}>Retry</button><small>Check VITE_API_BASE_URL, backend availability, and permissions.</small></div>}
      {loading && <div className="panel"><div className="paneltitle"><h3>Loading live ERP data…</h3></div><p>Fetching dashboard, orders, inventory, production and costing.</p></div>}
      <section className={`screen ${activeScreen === 'home' ? 'active' : ''}`} id="home">
        <div className="sectionhead"><h3>Order & inventory summary</h3><button onClick={() => void loadData(true)}>{refreshing ? 'Refreshing…' : '↻ Refresh'}</button></div>
        <div className="grid">
          <div className="metric" onClick={() => setActiveSheet('orders')}><div className="metrichead"><div className="ico">▤</div><span className="trend">Live</span></div><div className="value">{loading ? '—' : fmt(orderTotal)}</div><div className="label">Total sales orders</div><div className="subvalue">{fmt(orderedQty)} total ordered quantity (returned records)</div></div>
          <div className="metric" onClick={() => showScreen('orders')}><div className="metrichead"><div className="ico">◷</div><span className="trend">Live</span></div><div className="value">{loading ? '—' : fmt(openOrders.length)}</div><div className="label">Open orders</div><div className="subvalue">Based on current order statuses</div></div>
          <div className="metric wide" onClick={() => setActiveSheet('inventory')}><div><div className="metrichead"><div className="ico">▦</div><span className="trend">Stock value</span></div><div className="value">{loading ? '—' : money(inventory.total)}</div><div className="label">Inventory valuation</div></div><div className="right"><div style={{fontSize:10,color:'#718096'}}>Materials tracked</div><b style={{fontSize:17}}>{loading ? '—' : fmt(stockCount)}</b><div style={{fontSize:10,color:'#718096',marginTop:4}}>Live material records</div></div></div>
        </div>
        <div className="panel"><div className="paneltitle"><h3>Quick visual analysis</h3><span>Live API data</span></div>
          <div className="chartgrid">
            <div className="chartbox"><div className="charttitle">Sales order status</div><div className="legend livelegend">{Object.entries(orders.reduce((a: Record<string,number>, o) => { const s=String(o.status || 'Unknown'); a[s]=(a[s]||0)+1; return a; }, {})).map(([s,count])=><div key={s}><i></i>{s} {count}</div>)}</div><div className="chartcaption">Status breakdown of loaded sales orders</div></div>
            <div className="chartbox"><div className="charttitle">Inventory categories</div>{(inventory.breakdown || []).slice(0,6).map((r:any) => <div className="stage" key={r.category}><div className="stageline"><b>{r.category}</b><span>{money(r.value)}</span></div><div className="track"><div className="bar" style={{width:`${Math.min(100, n(r.value) / Math.max(1,...(inventory.breakdown||[]).map((x:any)=>n(x.value))) * 100)}%`}} /></div></div>)}{!(inventory.breakdown||[]).length && <p>No inventory category data returned.</p>}<div className="chartcaption">Valuation by material type</div></div>
          </div>
        </div>
        <div className="panel"><div className="paneltitle"><h3>Top WIP stages</h3><span>Live · quantity</span></div>
          {wipStages.length ? wipStages.slice(0,5).map((s:any,i:number)=><div className="stage" key={`${s.stage}-${i}`}><div className="stageline"><b>{val(s,'stage','stage_name')}</b><span>{fmt(val(s,'wip_qty','wipQty'))} · {fmt(val(s,'order_count','orderCount'))} orders</span></div><div className="track"><div className={`bar ${i===1?'teal':i===2?'orange':''}`} style={{width:`${Math.min(100, n(val(s,'wip_qty','wipQty'))/Math.max(1,...wipStages.map((x:any)=>n(val(x,'wip_qty','wipQty'))))*100)}%`}} /></div></div>) : <p>No WIP stage data returned by the dashboard API.</p>}
        </div>
        <div className="panel"><div className="paneltitle"><h3>Stock exceptions</h3><button onClick={()=>setActiveSheet('stock')}>View details</button></div>
          {lowStock.length ? lowStock.slice(0,5).map((m:any)=><div className="stockrow" key={m.id}><div><b>{val(m,'item','name')}</b><small>{val(m,'qty','current_qty')} / reorder {val(m,'threshold','reorder_level')}</small></div><span className={`status ${statusClass(m.status)}`}>{val(m,'status')}</span></div>) : <p>No low-stock items returned by the backend.</p>}
        </div>
      </section>
      <section className={`screen ${activeScreen === 'orders' ? 'active' : ''}`} id="orders">
        <div className="sectionhead"><h3>Sales orders</h3><span>{orders.length} loaded</span></div><input className="searchbox" placeholder="Search orders, customer or status…" value={search} onChange={e=>setSearch(e.target.value)} />
        <div className="panel"><div className="paneltitle"><h3>Order register</h3><span>Backend records</span></div><div className="tablewrap"><table><thead><tr><th>Order no.</th><th>Customer</th><th>Date</th><th>Qty</th><th>Status</th></tr></thead><tbody>{filteredOrders.map((o:any)=><tr key={o.id}><td>{val(o,'order_no','orderNo')}</td><td>{val(o,'customer_name','customerName')}</td><td>{date(val(o,'order_date','orderDate'))}</td><td>{fmt(val(o,'total_quantity','totalQuantity'))}</td><td><span className={`status ${statusClass(o.status)}`}>{val(o,'status')}</span></td></tr>)}</tbody></table>{!loading && !filteredOrders.length && <p className="empty">No sales orders returned from the API.</p>}</div></div>
      </section>
      <section className={`screen ${activeScreen === 'inventory' ? 'active' : ''}`} id="inventory">
        <div className="sectionhead"><h3>Inventory</h3><span>{materials.length} loaded</span></div><input className="searchbox" placeholder="Search material, code or type…" value={search} onChange={e=>setSearch(e.target.value)} />
        <div className="grid"><div className="metric"><div className="metrichead"><div className="ico">▦</div><span className="trend">Live</span></div><div className="value">{money(inventory.total)}</div><div className="label">Inventory valuation</div></div><div className="metric"><div className="metrichead"><div className="ico">⚠</div></div><div className="value">{lowStock.length}</div><div className="label">Low-stock alerts</div></div></div>
        <div className="panel"><div className="paneltitle"><h3>Material register</h3><span>Backend records</span></div><div className="tablewrap"><table><thead><tr><th>Code</th><th>Material</th><th>Type</th><th>UOM</th><th>Status</th></tr></thead><tbody>{filteredMaterials.map((m:any)=><tr key={m.id}><td>{val(m,'code','material_code')}</td><td>{val(m,'name','item')}</td><td>{val(m,'type','category')}</td><td>{val(m,'uom','unit')}</td><td><span className={`status ${statusClass(m.status)}`}>{val(m,'status')}</span></td></tr>)}</tbody></table>{!loading && !filteredMaterials.length && <p className="empty">No materials returned from the API.</p>}</div></div>
      </section>
      <section className={`screen ${activeScreen === 'costing' ? 'active' : ''}`} id="costing">
        <div className="sectionhead"><h3>Costing</h3><span>{costing.length} loaded</span></div><select className="searchbox" value={articleFilter} onChange={e=>setArticleFilter(e.target.value)}><option value="all">All articles</option>{Array.from(new Set(costing.map((c:any)=>String(val(c,'article')).trim()).filter(x=>x && x!=='—'))).map(a=><option key={a} value={a}>{a}</option>)}</select>
        <div className="panel"><div className="paneltitle"><h3>Costing report</h3><span>Backend records</span></div><div className="tablewrap"><table><thead><tr><th>Customer</th><th>Order no.</th><th>Article</th><th>Order qty</th><th>Completed</th><th>Cost / sqft</th><th>Selling / sqft</th><th>Variance</th></tr></thead><tbody>{filteredCosting.map((c:any,i:number)=><tr key={c.id ?? i}><td>{val(c,'customer_name','customer')}</td><td>{val(c,'order_no','orderNo')}</td><td>{val(c,'article')}</td><td>{fmt(val(c,'order_qty_sqft','order_qty'))}</td><td>{fmt(val(c,'completed_qty_sqft','completed_qty'))}</td><td>{money(val(c,'cost_per_sqft'))}</td><td>{money(val(c,'selling_price_per_sqft'))}</td><td>{money(val(c,'variance_per_sqft'))}</td></tr>)}</tbody></table>{!loading && !filteredCosting.length && <p className="empty">No costing records returned from the API.</p>}</div></div>
      </section>
      <section className={`screen ${activeScreen === 'production' ? 'active' : ''}`} id="production">
        <div className="sectionhead"><h3>Production</h3><span>{production.length} loaded</span></div><input className="searchbox" placeholder="Search production plan, stage or status…" value={search} onChange={e=>setSearch(e.target.value)} />
        <div className="panel"><div className="paneltitle"><h3>Production status orders</h3><span>Backend records</span></div><div className="tablewrap"><table><thead><tr><th>Plan / order</th><th>Article</th><th>Stage</th><th>Planned qty</th><th>Status</th></tr></thead><tbody>{filteredProduction.map((p:any,i:number)=><tr key={p.id ?? i}><td>{val(p,'plan_no','production_plan_no','order_no')}</td><td>{val(p,'article','product_name')}</td><td>{val(p,'process_stage','stage_name')}</td><td>{fmt(val(p,'planned_qty','order_qty','quantity'))}</td><td><span className={`status ${statusClass(p.status)}`}>{val(p,'status')}</span></td></tr>)}</tbody></table>{!loading && !filteredProduction.length && <p className="empty">No production records returned from the API.</p>}</div></div>
      </section>
    </main>
    <nav className="bottomnav">{nav.map(item=><button key={item.id} className={activeScreen===item.id?'selected':''} onClick={()=>{setSearch('');showScreen(item.id)}}><span>{item.icon}</span><small>{item.label}</small></button>)}</nav>
    {activeSheet && <div className="sheetbackdrop" onClick={()=>setActiveSheet(null)}><div className="sheet" onClick={e=>e.stopPropagation()}><button className="sheetclose" onClick={()=>setActiveSheet(null)}>×</button><h3>{currentSheetTitle}</h3><p>{currentSheetBody}</p><button onClick={()=>{setActiveSheet(null);showScreen(activeSheet==='inventory'||activeSheet==='stock'?'inventory':'orders')}}>Open details</button></div></div>}
  </div>;
}
